#include <stdio.h>
#include<string.h>
#include <stdlib.h>

struct Student{
  int id;
  char prezime[15];
  char ime[15];
};

int main(){

  FILE *p1=fopen("studenti.txt","r");
  if(p1==NULL) { 
    printf("Datoteka nije otvorena\n");
    return -1;
  }
  struct Student IT[31];
  char str[999],str1[999],str2[999],strid[999];
  int i=0;
  int j=0;
  int poljeid=0,poljeprezime=0,poljeime=0;
  while(fscanf(p1,"%s\n%s\n%s\n%s\n%s\n%s\n",str,strid,str1,IT[i].prezime,str2,IT[i].ime)!=EOF) {
    IT[i].id=atoi(strid);
    i++;
  }

  FILE *p2=fopen("studenti.dat","wb");
  if(p2==NULL) {
    printf("Datoteka nije otvorena\n");
    return -1;
  }
  for(int i=29;i>=0;i--){
    fprintf(p2,"Id: %d\nPrezime: %s\nIme: %s\n",IT[i].id,IT[i].prezime,IT[i].ime);
  }
  fclose(p1);
  fclose(p2);

  return 0;
}
