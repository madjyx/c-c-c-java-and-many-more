#include <stdio.h>
#include<string.h>
#include <stdlib.h>

struct Student{
  int id;
  char prezime[15];
  char ime[15];
};

int main(){

  FILE *p1=fopen("studenti.dat","a+");
  if(p1==NULL) { 
    printf("Datoteka nije otvorena\n");
    return -1;
  }
  struct Student novi;
  strcpy(novi.prezime,"Husic");
  strcpy(novi.ime,"Huso");
  novi.id=99;
  fseek(p1,0,SEEK_END);
  fprintf(p1,"Id: %d\nPrezime: %s\nIme: %s\n",novi.id,novi.prezime,novi.ime);
  rewind(p1);
  char str[999];
  while(fscanf(p1,"%s",str)!=EOF){
    if(strcmp(str,"Id:")==0)printf("\n");
    if(strcmp(str,"Prezime:")==0)printf("\n");
    if(strcmp(str,"Ime:")==0)printf("\n");
    printf("%s",str);
  }

  printf("\n");
  return 0;
}
