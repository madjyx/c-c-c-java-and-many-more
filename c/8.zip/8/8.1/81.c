#include<stdio.h>
#include<string.h>

struct Student{
  char prezime[15];
  char ime[15];
  int id;
};

int main(){

struct Student IT[30];
for(int i=0;i<30;i++){
  IT[i].id=i+1;
  printf("Unesite prezime studenta: ");
  scanf("%s",IT[i].prezime);
  printf("Unesite ime studenta: ");
  scanf("%s",IT[i].ime);
}

  FILE *p1=fopen("studenti.txt","w+");
  if(p1==NULL) {
    printf("Datoteka nije otvorena\n");
    return -1;}
  
    for(int i=0;i<30;i++){
      fprintf(p1,"Id: %d\nPrezime: %s\nIme: %s\n",IT[i].id,IT[i].prezime,IT[i].ime);
    }




return 0;
}
