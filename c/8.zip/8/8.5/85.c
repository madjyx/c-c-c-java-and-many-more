#include <stdio.h>
#include<string.h>
#include <stdlib.h>

struct Student{
  int id;
  char prezime[15];
  char ime[15];
};

int main(){

  FILE *p1=fopen("studenti.dat","a+");
  if(p1==NULL) { 
    printf("Datoteka nije otvorena\n");
    return -1;
  }
  FILE *p2=fopen("studenti.txt","w+");
  if(p2==NULL) {
    printf("Datoteka nije otvorena\n");
    return -1;
  }
  char str[999];
  int i=0;
  while(fscanf(p1,"%s",str)!=EOF){
    fprintf(p2,"%s",str);
    ++i;
    if(i%2==0)fprintf(p2,"\n");
    if(i%6==0)fprintf(p2,"\n");
  }
  
  fclose(p1);
  fclose(p2);
  
  return 0;
}
