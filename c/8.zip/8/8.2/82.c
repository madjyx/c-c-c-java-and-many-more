#include <stdio.h>
#include<string.h>
#include <stdlib.h>

struct Student{
  int id;
  char prezime[15];
  char ime[15];
};

int main(){

  FILE *p1=fopen("studenti.txt","r");
  if(p1==NULL) { 
    printf("Datoteka nije otvorena\n");
    return -1;
  }
  struct Student IT[30];
  char str[999];
  int i=0;
  int poljeid=0,poljeprezime=0,poljeime=0;
  while(fscanf(p1,"%s",str)!=EOF){
    if(i==1||i==7||i==13||i==19||i==25 ){
      IT[poljeid++].id=atoi(str);
    }
    if(i==3||i==9||i==15||i==21||i==27) {
      strcpy(IT[poljeprezime++].prezime,str);
    }
    if(i==5||i==11||i==17||i==23||i==29){
      strcpy(IT[poljeime++].ime,str);
    }
    if(++i==30) break;  }

  printf("ID studenata:\n");
  for(int i=0;i<5;i++)
    printf("%d\n",IT[i].id);
  printf("\nPrezime studenata:\n");
  for(int i=0;i<5;i++)
    printf("%s\n",IT[i].prezime);
  printf("\nImena studenata:\n");
  for(int i=0;i<5;i++)
    printf("%s\n",IT[i].ime);
  printf("\n");

  fclose(p1);
  return 0;
}
