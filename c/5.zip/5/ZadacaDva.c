#include<stdio.h>



int main(){

int matrica1[4][4];
int matrica2[4][4];
int matrica3[4][4];
int a,b;

printf("Unesite vrijednosti matrice1: \n");
for(a=0;a<4;a++){
    for(b=0;b<4;b++){
        printf("Unesite vrijednosti: ");
        scanf("%d",&matrica1[a][b]);
        getchar;
    }
}

printf("Matrica izgleda ovako \n ");
for(a=0;a<4;a++){
    for(b=0;b<4;b++){
printf("%3d",matrica1[a][b]);}printf("\n");

}

printf("Unesite vrijednosti matrice2: \n");
for(a=0;a<4;a++){
    for(b=0;b<4;b++){
        printf("Unesite vrijednosti: ");
        scanf("%d",&matrica2[a][b]);
        getchar;
    }
}

printf("Druga matrica izgleda ovako \n ");
for(a=0;a<4;a++){
    for(b=0;b<4;b++){
printf("%3d",matrica2[a][b]);}printf("\n");}

for(a=0;a<4;a++){
    for(b=0;b<4;b++){
            matrica3[a][b]=matrica1[a][0]*matrica2[0][b]+matrica1[a][1]*matrica2[1][b]+matrica1[a][2]*matrica2[2][b]+matrica1[a][3]*matrica2[3][b];
    }}
printf("\nKada pomnozimo dvije matrice rezultat izgleda ovako \n ");
for(a=0;a<4;a++){
    for(b=0;b<4;b++){
printf("%3d",matrica3[a][b]);}printf("\n");}
}
