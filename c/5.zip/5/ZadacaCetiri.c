#include<stdio.h>



int main(){

char niz[50]="Damir Koruga -Test -Test2";
const char a[2]="-";
char*token;

token=strtok(niz,a);
while(token != NULL){

    printf("%s\n",token);
    token=strtok(NULL,a);
}
return;



}
