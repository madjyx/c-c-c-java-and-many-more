#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

int sumfaktorijel(int num,...){
  va_list valist;
  int fakt;
  int i;
  int sum=0;
  va_start(valist,num);
  for(i=0;i<num;i++){
    fakt=1;
    int trenutni=va_arg(valist,int);
    if(trenutni==0) {
      printf("Specifican slucaj: faktorijel od 0 je 1\n");
      continue;
    }
    for(int j=trenutni;j>0;j--){
      fakt*=j;
    }
    sum+=fakt;
  }
  va_end(valist);
  return sum;
}

int main(){
  printf("suma faktorijela od 2,3,4,5 je: %d\n",sumfaktorijel(4,2,3,4,5));
  printf("Suma faktorijela od 6,9 je: %d\n",sumfaktorijel(2,6,9));
  return 0;
}
