#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#define petlja(i,x) for(int j=x;j<=x+i;j++) printf("%d ",j)


int main(){
  printf("Unesite donju granicu: ");
  int dg;
  scanf("%d",&dg);
  printf("Unesite broj: ");
  int gg;
  scanf("%d",&gg);
  printf("Rezultat je: ");
  petlja(gg,dg);
  printf("\n");


  return 0;
}
