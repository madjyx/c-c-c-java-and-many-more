#include <stdio.h>
#include <stdlib.h>


int main(){
  void *ptr;
  int m1[3][3]={
    {1,2,3},
    {4,5,6},
    {7,8,9},
  };
  float m2[3][3]={
    {1.1,2.2,3.3},
    {4.4,5.5,6.6},
    {7.7,8.8,9.9},
  };
  char m3[3][3]={
    {'a','b','c'},
    {'d','e','f'},
    {'g','h','j'},
  };

 
  for(int i=0,j=0,z=0;i<3&&j<3&&z<9;){
      printf("%d. clan:\t",z+1);
      ptr=&m1[i][j];
      printf("%d ",*((int*)ptr));
      ptr=&m2[i][j];
      printf("%.1f ",*((float*)ptr));
      ptr=&m3[i][j];
      printf("%c\n",*((char*)ptr));
      ++j;
      ++z;
      if(j%3==0){++i;j=0; 
      }
  }

  return 0;
}
