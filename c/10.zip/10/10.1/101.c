#include <stdio.h>
#include <stdlib.h>

typedef struct cvor_liste{
  int broj;
  struct cvor_liste *next;
} cvor;

void print(cvor *first){
  cvor *tr=first;
  while(tr!=NULL){
    printf("%d ",tr->broj);
    tr=tr->next;
  }
  printf("\n");
}


int main(){
  cvor *prvi=malloc(sizeof(cvor));
  printf("Unesite broj elemenata liste: ");
  int n;
  scanf("%d",&n);
  cvor *trenutni=prvi;
  printf("Unesite listu %d brojeva:\n",n);
  int br;
  for(int i=0;i<n;i++){
    scanf("%d",&br);
    trenutni->broj=br;
    if(i!=n-1){trenutni->next=malloc(sizeof(cvor));
    trenutni=trenutni->next;
  }
    else{trenutni->next=NULL;}
  }
  printf("Unesena lista je:\n");
  print(prvi);
  
  cvor *temp1,*temp2;
  int pomocna;
  temp1=prvi;
  temp2=prvi->next;
  for(int i=0;i<n;i++){
    if(temp1==NULL || temp2==NULL) continue;
    for(int j=0;j<n-i;j++){
      if(temp2==NULL) continue;
      if(temp1->broj>temp2->broj){
        pomocna=temp1->broj;
        temp1->broj=temp2->broj;
        temp2->broj=pomocna;
      }
      temp2=temp2->next;
    }
    temp1=temp1->next;
    temp2=temp1->next;
  }

  printf("Sortirana lista:\n");
  print(prvi);

  printf("Unesite trazeni broj: ");
  int potraga;
  int kontrola=0;
  scanf("%d",&potraga);
  trenutni=prvi;
  for(int i=0;i<n;i++){
    if(trenutni->broj==potraga){
      kontrola=1;
      break;
    }
    else{
      trenutni=trenutni->next;
    }
  }
  if(kontrola) printf("Broj je pronadjen\n");
  else printf("Broj nije pronadjen\n");

  
  
  return 0;
}
