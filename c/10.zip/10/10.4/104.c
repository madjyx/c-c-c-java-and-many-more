#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "greska.h"
//#define GRESKA_H
#if !defined(GRESKA_H)
#error Greska
#endif


int main(){


  return 0;
}
