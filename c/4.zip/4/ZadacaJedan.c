#include<stdio.h>
#include"Damir.h"

int a=10;
int b=5;
int c=6;

int main(){

int x=10;
int y=15;
int rez;
rez=suma(x,y);
printf("Suma x %d i y %d je %d ",x,y,rez);
return 0;




}
