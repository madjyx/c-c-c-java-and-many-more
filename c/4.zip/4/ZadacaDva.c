#include<stdio.h>
#include<time.h>



int main(){

    time_t vrijeme;
    time(&vrijeme);
    struct tm tm = *localtime(&vrijeme);

    printf("Trenutno sati :\n%d:%d:%d\n\n",tm.tm_hour,tm.tm_min,tm.tm_sec);
    printf("Datum :\n%d-%d-%d\n\n",tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday);
    printf("Trenutni dan u godini je: \n%d.\n\n",tm.tm_yday+1);
    printf("Trenutni dan u sedmici je:\n%d.\n\n",tm.tm_wday);
    printf("Kalendarski prikaz svih informacija :\n%s\n",ctime(&vrijeme));



}
