#include<stdio.h>
#include"Damir.h"

int a=10;
int b=5;
int c=15;



int main(){


obim();
return 0;


}
