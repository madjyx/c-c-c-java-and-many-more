#include<stdio.h>




int main(){

int a,b,c,d,e,f,g,rez;
printf("Unesite sedam vrijednosti koje moraju biti cijeli broj\n");
scanf("%d%d%d%d%d%d%d",&a,&b,&c,&d,&e,&f,&g);
rez=funkcija(a,b,c,d,e,f,g);
printf("Suma brojeva kojih ste unijeli je: %d",rez);
return 0;


}


int funkcija(int a,int b,int c,int d,int e,int f,int g){

int x=a+b+c+d+e+f+g;
return(x);
}
