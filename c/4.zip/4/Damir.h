#ifndef DAMIR_H_INCLUDED
#define DAMIR_H_INCLUDED

extern int a;
extern int b;
extern int c;

void obim(){

printf("Obim trougla je: %d + %d + %d = %d\n",a,b,c,a+b+c);
}
int suma(int a, int b){
int c=a+b;
return (c);

}


#endif // DAMIR_H_INCLUDED
