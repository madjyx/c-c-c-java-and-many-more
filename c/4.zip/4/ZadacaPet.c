#include <stdio.h>
#include <stdlib.h>


int main(int argc,char *argv[])
{
    int a;
    printf("UNESI BROJ ");
    scanf("%d", &a);
    int b=proizvod(a);
    printf("Proizvod neparnih brojeva je: %d",b);
    return 0;

return 0;
}


int proizvod(int s)
{
    if(s%2==0){
        s-=1;
    }
    if(s != 1)
        return s*proizvod(s-2);
    else
        return s;
}


