#include<stdio.h>



int main(){

char ime[]="Damir";
char prezime[]="Koruga";

printf("Moje ime je %s i prezime %s\n",ime,prezime);
printf("%s\n",prezime);
printf("%10s\n",ime);
printf("%s\n",ime);



}
