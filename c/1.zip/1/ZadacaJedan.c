#include<stdio.h>


int main (){

//DAMIR KORUGA

printf("DDD     K     K");
printf("D  D    K    K");
printf("D   D   K   K");
printf("D    D  K  K ");
printf("D     D K K  ");
printf("D     D K  K ");
printf("D     D K   K ");
printf("D    D  K    K");
printf("D  D    K     K");
printf("DD      K      K");





}
