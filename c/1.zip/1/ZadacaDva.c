#include<stdio.h>



int main(){


int a;
printf("Unesite jedan cijeli broj: \n");
scanf("%d",&a);
printf("Cijeli broj: %d\n",a);
printf("Realni broj: %f\n",a);
printf("Oktalni broj: %o\n",a);
printf("Heksadecimalni broj: %x\n",a);


return 0;



}
