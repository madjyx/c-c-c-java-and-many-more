#include<stdio.h>

//ZAPREMINA KOCKE

int main(){

int a,rezultat;
printf("Unesite duzinu jedne stranice kocke: ");
scanf("%d",&a);
rezultat=a*a*a;
printf("Zapremina kocke iznosi: %d\n",rezultat);




}
