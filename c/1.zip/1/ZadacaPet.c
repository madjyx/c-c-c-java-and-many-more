#include<stdio.h>


int main(){

float a,rezultat;
printf("Unesite vrijednost valute(Svajcarski franak): ");
scanf("%f",&a);

rezultat=a+11362.99702;

printf("\nSvajcarski franak konvertovan u Japanski jen iznosi: %f \n",rezultat);
return 0;



}
