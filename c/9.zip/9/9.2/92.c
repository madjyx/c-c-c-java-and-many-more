#include <stdio.h>
#include <stdlib.h>

typedef struct cvor_liste{
  int broj;
  struct cvor_liste *next;
} cvor;

void print(cvor *first){
  cvor *tr=first;
  while(tr!=NULL){
    printf("%d ",tr->broj);
    tr=tr->next;
  }
  printf("\n");
}


int main(){
  cvor *prvi=malloc(sizeof(cvor));
  cvor *drugi=malloc(sizeof(cvor));
  int pr,dr;
  printf("Unesite prvi broj Fibonaccijevog niza: ");
  scanf("%d",&pr);
  printf("Unesite drugi broj Fibonaccijevog niza: ");
  scanf("%d",&dr);
  prvi->broj=pr;
  prvi->next=drugi;
  drugi->broj=dr;
  cvor *trenutni=malloc(sizeof(cvor));
  drugi->next=trenutni;
  int duzinaliste=10;
  int slj;
  for(int i=0;i<duzinaliste;i++){
    trenutni->broj=pr+dr;
    slj=pr+dr;
    pr=dr;
    dr=slj;
    if(i!=duzinaliste-1){trenutni->next=malloc(sizeof(cvor));
    trenutni=trenutni->next;
  }
  }
  print(prvi);
  return 0;
}
