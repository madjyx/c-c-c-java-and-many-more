#include <stdio.h>
#include <stdlib.h>

typedef struct cvor_liste{
  int broj;
  struct cvor_liste *next;
} cvor;

void print(cvor *first){
  cvor *tr=first;
  while(tr!=NULL){
    printf("%d ",tr->broj);
    tr=tr->next;
  }
  printf("\n");
}


int main(){
  cvor *prvi=malloc(sizeof(cvor));
  cvor *drugi=malloc(sizeof(cvor));
  int pr,dr;
  printf("Unesite prvi broj Fibonaccijevog niza: ");
  scanf("%d",&pr);
  printf("Unesite drugi broj Fibonaccijevog niza: ");
  scanf("%d",&dr);
  prvi->broj=pr;
  prvi->next=drugi;
  drugi->broj=dr;
  cvor *trenutni=malloc(sizeof(cvor));
  drugi->next=trenutni;
  int duzinaliste=20;
  int slj;
  for(int i=0;i<duzinaliste;i++){
    trenutni->broj=pr+dr;
    slj=pr+dr;
    pr=dr;
    dr=slj;
    if(i!=duzinaliste-1){trenutni->next=malloc(sizeof(cvor));
    trenutni=trenutni->next;
  }
  }
  printf("Lista prije brisanja svakog treceg cvora:\n");
  print(prvi);
  
  cvor *stari=malloc(sizeof(cvor));
  trenutni=prvi;
  stari=trenutni;
  for(int i=1;i<duzinaliste;i++){
    if(i%3==0) stari->next=trenutni->next;
    stari=trenutni;
    trenutni=trenutni->next;
  }

  printf("Lista nakon brisanja svakog treceg cvora:\n");
  print(prvi);
  
  
  return 0;

}
