#include <stdio.h>
#include <stdlib.h>

typedef struct cvor_liste{
  int broj;
  struct cvor_liste *next;
  struct cvor_liste *before;
} cvor;

void print(cvor *glava){
  while(glava->next!=NULL){
    printf("%d ",glava->broj);
    glava=glava->next;
  }
  printf("\n");
}
void printback(cvor *zadnji){
  while(zadnji->before!=NULL){
    printf("%d ",zadnji->broj);
    zadnji=zadnji->before;
  }
  printf("\n");
}

int main(){
  cvor *prvi=malloc(sizeof(cvor));
  cvor *drugi=malloc(sizeof(cvor));
  int pr,dr;
  printf("Unesite prvi broj Fibonaccijevog niza: ");
  scanf("%d",&pr);
  printf("Unesite drugi broj Fibonaccijevog niza: ");
  scanf("%d",&dr);
  prvi->broj=pr;
  prvi->next=drugi;
  prvi->before=NULL;
  drugi->broj=dr;
  cvor *trenutni=malloc(sizeof(cvor));
  drugi->next=trenutni;
  trenutni->before=drugi;
  int duzinaliste=10;
  int slj;
  for(int i=0;i<duzinaliste;i++){
    trenutni->broj=pr+dr;
    slj=pr+dr;
    pr=dr;
    dr=slj;
    if(i!=duzinaliste){trenutni->next=malloc(sizeof(cvor));
    trenutni->next->before=trenutni;
    trenutni=trenutni->next;
  }
  }
  trenutni=trenutni->before;
  printf("Dvostruko povezana lista:\n");
  print(prvi);
  printf("Dvostruko povezana lista ispisana unazad:\n");
  printback(trenutni);
  return 0;
}
