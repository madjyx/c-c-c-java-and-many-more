#include <stdio.h>
#include <stdlib.h>
struct Student{
  int id;
  char ime[15];
  char prezime[15];
};


int main(){
  struct Student *ptr;
  //alokacija memorije za 100 struktura
  ptr=(struct Student*)malloc(100*sizeof(struct Student));
  //realokacija za 200 struktura
  ptr=realloc(ptr,200*sizeof(struct Student));
  //oslobadjanje memorije
  free(ptr);



  return 0;
}
