#include<stdint.h>




int main(){


int a,b;

printf("Unesite starosnu dob korisnika: ");
scanf("%d",&a);
if(a>80 && a<100)printf("Jako stara osoba\n");
else if(a>65 && a<=80)printf("Osoba koja uziva u mirovini\n");
else if(a>45 && a<=65)printf("Starija osoba\n");
else if(a>25 && a<=45)printf("Osoba spremna preuzeti odgovornost\n");
else if(a>=18 && a<=25)printf("Mlada osoba\n");
else if(a>1 && a<18)printf("Maloljetna osoba\n");
else printf("Unos nije validan");
printf("\nDa li ste musko ili zensko\n");
printf("1. MUSKO\n2. ZENSKO\n");
scanf("%d",&b);
switch(b){
case 1:
    printf("Vi ste musko");
    break;
case 2:
    printf("Vi ste zensko");
    break;
}

return 0;



}
