#include<stdio.h>



int main(){

int a;
printf("Izaberite izmedju\n1. INT2. FLOAT\n3. CHAR\n");
scanf("%d",&a);
if(a==1)printf("Izabrali ste INT oznaku za cijeli broj\n");
else if(a==2)printf("Izabrali ste FLOAT oznaku za realni broj\n");
else if(a==3)printf("Izabrali ste CHAR oznaku za karaktere");
else printf("Unos nije validan");

return 0;



}
