#include<stdio.h>




int main(){

int a,b,c;
a=0;
b=0;

do{
    while(b<10){
        for(c=0;c<10;c++){
            printf("%d * %d = %d",b,c,b*c);
        }b++;
    }a++;
}while(a<10);




}
