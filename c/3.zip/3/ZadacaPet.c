#include<stdio.h>

int main(){

int a;

printf("Dobrodosli simulaciju RESTORANA. Sta zelite da narucite?");
printf("1. Piletina sa zara\n2. Pizza\n3. Samo salata\n 4. Napustate restoran");
scanf("%d",&a);
if(a>4 && a<1)printf("Unos nije validan");
switch(a){
case 1:
    printf("Piletina sa zara je jako dobar izbor\n");
    printf("Sta zalite kao prilog:\n");
    printf("1. Pekarski krompir\n2. Zelena salata");
    scanf("%d",&a);
    if(a>2 && a<1)printf("Unos nije validan");
    switch(a){
    case 1:
        printf("Izabrali ste Piletinu sa zara i Pekarski krompir, to vam je 10KM\n");
        break;
    case 2:
        printf("Izabrali ste Piletinu sa zara i Zelenu salatu, to vam je 8KM\n");
        break;}
        break;
case 2:
    printf("Pizza je po italijanskom receptu\n");
    printf("Sta zalite kao prilog:\n");
    printf("1. Paradajz sos\n2. Zelenu salatu");
    scanf("%d",&a);
    if(a>2 && a<1)printf("Unos nije validan");
    switch(a){
    case 1:
        printf("Izabrali ste Pizzu sa Paradajz sosom, to vam je 6KM\n");
        break;
    case 2:
        printf("Izabrali ste Pizzu i Zelenu salatu, to vam je 5KM\n");
        break;}
        break;
case 3:
    printf("Salata je mnogo zdrava\n");
    printf("Posto ste uzeli samo salatu zelite li nesto za pice:\n");
    printf("1. Gazirani sok\n2. Prirodni sok");
    scanf("%d",&a);
    if(a>2 && a<1)printf("Unos nije validan");
    switch(a){
    case 1:
        printf("Izabrali ste Salatu i Gazirani sok, to vam je 5KM\n");
        break;
    case 2:
        printf("Izabrali ste Salatu i Prirodni sok, to vam je 7KM\n");
        break;}
        break;
case 4:
   printf("Jako nam je zao sto nas napustate\n");
   break;



}
return 0;

}
