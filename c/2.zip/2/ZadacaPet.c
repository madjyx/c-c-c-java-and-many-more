#include<stdio.h>



int main(){

long double a;
a=20.182341;

printf("Memoriska vrijednost 1: %Lf\n",a);
printf("Memoriska vrijednost 2: %lf\n", (double)a);
printf("Memoriska vrijednost 3: %f\n", (float)a);
printf("Memoriska vrijednost 4: %d\n", (int)a);
printf("Memoriska vrijednost 5: %d\n", (short)a);
printf("Memoriska vrijednost 6: %c\n", (char)a);



}
