#include<stdio.h>



int main(){


unsigned int a;

for(a=0;a<=255;a++){
    printf("Asci tabela %d=%c\n",a,a);
}

return 0;

}
