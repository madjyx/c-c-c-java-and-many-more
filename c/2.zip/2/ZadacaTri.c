#include<stdio.h>



int main(){


typedef int stranica;

stranica a=10,rezultat;
rezultat=a*a*a;
printf("Zapremina kocke iznosi: %d",rezultat);
return 0;




}
