#include<stdio.h>


int main(){
 int a,b,rezultat;
 a=5;
 b=10;
 printf("Zadane varijable su: a=%d i b=%d\n",a,b);
 rezultat=a&b;
 /* a= 00000101
    b= 00001010
    rezultat= 00000000 = 0*/
 printf("Rezultat logickog I sa bitima je: %d\n",rezultat);
 rezultat=a|b;
 /* a= 00000101
    b= 00001010
    rezultat= 00001111 = 15*/
 printf("Rezultat logickog ILI sa bitima je: %d\n",rezultat);
 rezultat=a^b;
 /* a= 00000101
    b= 00001010
    rezultat= 00001111 = 15*/
 printf("Rezultat ekskluzivnog Logickog ILI sa bitima je: %d\n",rezultat);
 rezultat=~a;
  /* a= 00000101
    b= 00001010
    rezultat= 1111111111111111111111111111111111111111111111111111111111111010 = -6*/
 printf("Rezultat prvog komplementa sa bitima je: %d\n",rezultat);
 rezultat=a>>2;
 /* a= 00000101
    b= 00001010
    rezultat= 00000001 = 1*/
 printf("Rezultat pomjeranje bita u desno za 2 je: %d\n",rezultat);
 rezultat=a<<2;
 /* a= 00000101
    b= 00001010
    rezultat= 00010100 = 20 */
 printf("Rezultat pomjeranje bita u lijevo za 2 je: %d\n",rezultat);
 rezultat=b>>2;
 /* a= 00000101
    b= 00001010
    rezultat= 00000010 = 2 */
 printf("Rezultat pomjeranje bita u desno za 2 je: %d\n",rezultat);
 rezultat=b<<2;
 /* a= 00000101
    b= 00001010
    rezultat= 00101000 = 40 */
 printf("Rezultat pomjeranje bita u lijevo za 2 je: %d\n",rezultat);

}





