#include<stdio.h>



int main(){

int a=10;
float b=15;
char c='A';

printf("Formateri sa koristenjem cijelog broja: \n");
printf("Cijeli broj: %d\n",a);
printf("Realni broj: %f\n",a);
printf("Oktalni broj: %o\n",a);
printf("Heksadecimalni broj: %x\n",a);
printf("Karakter: %c\n",a);
printf("String: %c\n",a);

printf("\nFormateri sa koristenjem realnog broja: \n");
printf("Cijeli broj: %d\n",b);
printf("Realni broj: %f\n",b);
printf("Oktalni broj: %o\n",b);
printf("Heksadecimalni broj: %x\n",b);
printf("Karakter: %c\n",b);
printf("String: %c\n",b);

printf("\nFormateri sa koristenjem karaktera \n");
printf("Cijeli broj: %d\n",c);
printf("Realni broj: %f\n",c);
printf("Oktalni broj: %o\n",c);
printf("Heksadecimalni broj: %x\n",c);
printf("Karakter: %c\n",c);
printf("String: %c\n",c);







}
