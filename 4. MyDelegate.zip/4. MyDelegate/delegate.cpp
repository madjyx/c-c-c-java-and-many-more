#include "delegate.h"

Delegate::Delegate()
{

}

QWidget *Delegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    QSpinBox *editor=new QSpinBox(parent);
    editor->setMinimum(0);
    editor->setMaximum(100);
    return editor;
}

void Delegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    //from model into the editor(delegate)
    int value= index.model()->data(index,Qt::EditRole).toInt();
    QSpinBox *spinbox=static_cast<QSpinBox*>(editor);
    spinbox->setValue(value);
}

void Delegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    QSpinBox *spinbox=static_cast<QSpinBox*>(editor);
    spinbox->interpretText();
    model->setData(index,value, Qt::EditRole);

}

void Delegate::updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    editor->setGeometry(option.rect);
}
